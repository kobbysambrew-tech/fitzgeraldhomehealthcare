# Fitzgerald Home Health Care — Website Concept

Open `index.html` in a browser to preview the site.

Included:
- Responsive modern redesign using Fitzgerald's cyan / blue / purple logo palette
- Local logo asset
- Home, About, Services, Our Approach, Careers, and Contact sections
- Employment application and background study authorization downloads
- Mobile navigation
- No external framework required

Source content is based on the existing Fitzgerald Home Health Care website and the supplied employment documents.
