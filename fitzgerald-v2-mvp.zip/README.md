# Fitzgerald Home Health Care — V2 MVP

This build is the frontend MVP: redesigned website, services, careers, online application UI, background-study UI, and admin dashboard preview.

The forms are NOT connected to Firebase yet. Do not use them with real SSNs or other sensitive data until authentication, server-side handling, Firestore/Storage rules, document generation, and testing are completed.

Next step: create the Firebase project and wire the backend.
