// Add the public Firebase web config after creating the Fitzgerald project.
// Never commit service-account JSON, private keys, or other server secrets.
export const firebaseConfig = {apiKey:"REPLACE",authDomain:"REPLACE",projectId:"REPLACE",storageBucket:"REPLACE",messagingSenderId:"REPLACE",appId:"REPLACE"};
